'use strict'

var mongoose = require('mongoose');
var Schema = mongoose.Schema;
//Json con los campos que son los mismo que tiene mi modelo de la base de datos
var UserSchema = Schema({
	name: String,
	surname: String,
	email: String,
	especiality: String,
	password: String,
	image: String,
	role: String
});

module.exports = mongoose.model('User', UserSchema);
