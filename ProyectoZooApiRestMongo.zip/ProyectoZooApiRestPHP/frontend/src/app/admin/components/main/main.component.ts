import { Component, DoCheck, OnInit } from '@angular/core';

@Component({
  selector: 'admin-main',
  templateUrl: './main.component.html'
})
export class MainComponent {
  	title = 'Panel de administración';
  	
}
